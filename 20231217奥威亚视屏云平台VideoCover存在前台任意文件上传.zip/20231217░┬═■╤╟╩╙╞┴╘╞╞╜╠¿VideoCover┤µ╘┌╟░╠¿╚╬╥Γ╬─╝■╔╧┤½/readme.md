# fofa语法：

body="/CSS/NewtonTheme/assets/app.css"



# 使用



python poc.py -u ip:port

python poc.py -f url.txt

![image-20231218141232094](assets/image-20231218141232094.png)

![image-20231218141301264](assets/image-20231218141301264.png)

webshell默认密码 y1k1ng

冰蝎连接

![image-20231218141409421](assets/image-20231218141409421.png)

由于传播、利用所发布的项目造成的任何直接或者间接的后果及损失，均由使用者本人承担。原文章作者不为此承担任何责任，一旦造成后果请自行承担！如有侵权烦请告知，我们会立即删除并致歉。谢谢！

